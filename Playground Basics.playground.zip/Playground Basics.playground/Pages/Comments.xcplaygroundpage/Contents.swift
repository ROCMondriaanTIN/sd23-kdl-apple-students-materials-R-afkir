/*:
## Comments
Clarity and readability are important considerations when writing code. Programmers leave little notes right in the code to help explain what's going on.
This helps other people understand the code when they read it later.
These notes are called _comments_.

Comments are ignored by the playground and don't affect how your code is run.

A comment starts with two slashes `//` :
 */
// This is a comment; it does not affect the code
//34 + 56 + 230
//: Because comments are ignored, no result is displayed in the results bar for that line of code.
200 + 34 + 45200 + 34 + 45
200 + 34 + 45
// Total money (in dollars): Coin jar, wallet, and bank account
34 + 56 + 230

// Minutes of violin practice: Two weeks ago, last week, and this week
200 + 34 + 45
/*:
Take a deep breath and move on to the next page.

[Previous](@previous)  |  page 4 of 7  |  [Next: When Things Go Wrong 😰](@next)
 */
